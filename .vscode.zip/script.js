function showWelcome() {
    alert("Welcome to PRAROZ!");
}

function searchServices() {

    let input =
    document.getElementById("searchBox")
    .value.toLowerCase();

    let items =
    document.querySelectorAll("#serviceList li");

    items.forEach(item => {

        if(item.textContent
            .toLowerCase()
            .includes(input)) {

            item.style.display = "";

        } else {

            item.style.display = "none";
        }
    });
}

function validateEnquiry() {

    let name =
    document.getElementById("ename").value;

    if(name.length < 3) {

        alert("Name must be at least 3 characters.");
        return false;
    }

    alert("Enquiry Submitted");
    return true;
}

function validateContact() {

    let phone =
    document.getElementById("phone").value;

    if(phone.length < 10) {

        alert("Invalid phone number");
        return false;
    }

    alert("Message Sent");
    return true;
}

function openLightbox(src) {

    document.getElementById("lightbox")
    .style.display = "block";

    document.getElementById("lightbox-img")
    .src = src;
}

function closeLightbox() {

    document.getElementById("lightbox")
    .style.display = "none";
}